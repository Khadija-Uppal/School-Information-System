﻿using School_Information_System;
using SchoolInformationSystem.Data;
using SchoolInformationSystem.Models;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace SchoolInformationSystem.Forms
{
    public partial class DashboardForm : Form
    {
        private Database db;

        public DashboardForm()
        {
            InitializeComponent();
            InitializeDashboard();
            LoadStats();
        }

        private void InitializeComponent()
        {
            // Main Form
            this.Text = "School Management Dashboard";
            this.Size = new Size(1200, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 242, 245);

            // Sidebar
            InitializeSidebar();

            // Header
            InitializeHeader();

            // Stats Cards
            InitializeStatsCards();

            // Main Content
            InitializeMainContent();
        }

        private void InitializeSidebar()
        {
            Panel sidebar = new Panel
            {
                Size = new Size(250, 700),
                BackColor = Color.FromArgb(41, 53, 65),
                Location = new Point(0, 0)
            };

            // Logo
            Label logo = new Label
            {
                Text = "🏫 EduSys",
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.White,
                Size = new Size(230, 60),
                Location = new Point(10, 20),
                TextAlign = ContentAlignment.MiddleCenter
            };
            sidebar.Controls.Add(logo);

            // Menu Items
            string[] menuItems = { "Dashboard", "Students", "Teachers", "Attendance", "Results", "Settings", "Logout" };
            string[] icons = { "📊", "👨‍🎓", "👨‍🏫", "📅", "📈", "⚙️", "🚪" };

            for (int i = 0; i < menuItems.Length; i++)
            {
                Button menuBtn = new Button
                {
                    Text = $"  {icons[i]}  {menuItems[i]}",
                    Font = new Font("Segoe UI", 11),
                    ForeColor = Color.White,
                    BackColor = Color.Transparent,
                    FlatStyle = FlatStyle.Flat,
                    Size = new Size(250, 50),
                    Location = new Point(0, 100 + (i * 55)),
                    TextAlign = ContentAlignment.MiddleLeft,
                    Tag = menuItems[i]
                };

                menuBtn.FlatAppearance.BorderSize = 0;
                menuBtn.FlatAppearance.MouseOverBackColor = Color.FromArgb(74, 111, 165);

                if (menuItems[i] == "Dashboard")
                    menuBtn.BackColor = Color.FromArgb(74, 111, 165, 50);

                menuBtn.Click += MenuButton_Click;
                sidebar.Controls.Add(menuBtn);
            }

            this.Controls.Add(sidebar);
        }

        private void InitializeHeader()
        {
            Panel header = new Panel
            {
                Size = new Size(950, 80),
                BackColor = Color.White,
                Location = new Point(250, 0)
            };

            Label title = new Label
            {
                Text = "School Management Dashboard",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                ForeColor = Color.FromArgb(41, 53, 65),
                Size = new Size(400, 40),
                Location = new Point(30, 20)
            };

            // User Profile
            Panel userPanel = new Panel
            {
                Size = new Size(200, 40),
                Location = new Point(700, 20),
                BackColor = Color.Transparent
            };

            PictureBox userPic = new PictureBox
            {
                Size = new Size(40, 40),
                Location = new Point(0, 0),
                Image = GetDefaultAvatar(),
                SizeMode = PictureBoxSizeMode.StretchImage
            };

            Label userName = new Label
            {
                Text = "Admin User",
                Font = new Font("Segoe UI", 11),
                ForeColor = Color.FromArgb(41, 53, 65),
                Size = new Size(150, 40),
                Location = new Point(50, 0),
                TextAlign = ContentAlignment.MiddleLeft
            };

            userPanel.Controls.Add(userPic);
            userPanel.Controls.Add(userName);

            header.Controls.Add(title);
            header.Controls.Add(userPanel);
            this.Controls.Add(header);
        }

        private void InitializeStatsCards()
        {
            Panel statsPanel = new Panel
            {
                Size = new Size(950, 120),
                Location = new Point(250, 90),
                BackColor = Color.Transparent
            };

            // Create 4 stat cards
            string[] titles = { "Students", "Teachers", "Parents", "Earnings" };
            string[] values = { "15.00K", "2.00K", "5.6K", "$19.3K" };
            Color[] colors =
            {
                Color.FromArgb(102, 126, 234),
                Color.FromArgb(245, 87, 108),
                Color.FromArgb(79, 172, 254),
                Color.FromArgb(67, 233, 123)
            };

            for (int i = 0; i < 4; i++)
            {
                Panel card = new Panel
                {
                    Size = new Size(220, 100),
                    Location = new Point(20 + (i * 230), 10),
                    BackColor = Color.White,
                    BorderStyle = BorderStyle.None
                };

                // Icon Circle
                Panel iconCircle = new Panel
                {
                    Size = new Size(50, 50),
                    Location = new Point(20, 25),
                    BackColor = colors[i],
                    BorderRadius = 25
                };

                Label icon = new Label
                {
                    Text = i == 0 ? "👨‍🎓" : i == 1 ? "👨‍🏫" : i == 2 ? "👨‍👩‍👧" : "💰",
                    Font = new Font("Segoe UI", 20),
                    ForeColor = Color.White,
                    Size = new Size(50, 50),
                    TextAlign = ContentAlignment.MiddleCenter
                };

                // Stats Values
                Label valueLabel = new Label
                {
                    Text = values[i],
                    Font = new Font("Segoe UI", 22, FontStyle.Bold),
                    ForeColor = Color.FromArgb(41, 53, 65),
                    Size = new Size(120, 40),
                    Location = new Point(80, 20)
                };

                Label titleLabel = new Label
                {
                    Text = titles[i],
                    Font = new Font("Segoe UI", 11),
                    ForeColor = Color.FromArgb(127, 140, 141),
                    Size = new Size(120, 30),
                    Location = new Point(80, 60)
                };

                iconCircle.Controls.Add(icon);
                card.Controls.Add(iconCircle);
                card.Controls.Add(valueLabel);
                card.Controls.Add(titleLabel);

                statsPanel.Controls.Add(card);
            }

            this.Controls.Add(statsPanel);
        }

        private void InitializeMainContent()
        {
            Panel mainContent = new Panel
            {
                Size = new Size(950, 490),
                Location = new Point(250, 220),
                BackColor = Color.Transparent
            };

            // Left Panel - Chart
            Panel chartPanel = new Panel
            {
                Size = new Size(620, 470),
                Location = new Point(0, 0),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };

            Label chartTitle = new Label
            {
                Text = "All Exam Results",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Size = new Size(200, 40),
                Location = new Point(20, 20)
            };

            // Chart placeholder
            PictureBox chartImage = new PictureBox
            {
                Size = new Size(580, 350),
                Location = new Point(20, 70),
                BackColor = Color.FromArgb(248, 249, 250),
                BorderStyle = BorderStyle.FixedSingle
            };

            // Add some chart-like graphics
            chartImage.Paint += (s, e) =>
            {
                Graphics g = e.Graphics;
                Pen pen = new Pen(Color.FromArgb(74, 111, 165), 2);

                // Draw axes
                g.DrawLine(pen, 50, 300, 550, 300); // X-axis
                g.DrawLine(pen, 50, 50, 50, 300);   // Y-axis

                // Draw bars
                Random rand = new Random();
                int barWidth = 40;
                for (int i = 0; i < 10; i++)
                {
                    int height = rand.Next(50, 250);
                    g.FillRectangle(Brushes.SteelBlue,
                        80 + (i * 50), 300 - height, barWidth, height);
                }

                pen.Dispose();
            };

            chartPanel.Controls.Add(chartTitle);
            chartPanel.Controls.Add(chartImage);

            // Right Panel - Star Students
            Panel studentsPanel = new Panel
            {
                Size = new Size(310, 470),
                Location = new Point(630, 0),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };

            Label studentsTitle = new Label
            {
                Text = "Star Students",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Size = new Size(200, 40),
                Location = new Point(20, 20)
            };

            // Star Students Table
            DataGridView dgvStarStudents = new DataGridView
            {
                Size = new Size(270, 380),
                Location = new Point(20, 70),
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };

            dgvStarStudents.Columns.Add("Name", "Name");
            dgvStarStudents.Columns.Add("ID", "ID");
            dgvStarStudents.Columns.Add("Marks", "Marks");
            dgvStarStudents.Columns.Add("Percent", "Percent");

            // Add sample data
            dgvStarStudents.Rows.Add("Everyin Harper", "PREJ:3178", "185", "98%");
            dgvStarStudents.Rows.Add("Diana Plenty", "PREJ:3174", "165", "91%");
            dgvStarStudents.Rows.Add("John Millar", "PREJ:3187", "175", "92%");
            dgvStarStudents.Rows.Add("Miles Esther", "PREJ:5371", "180", "93%");

            studentsPanel.Controls.Add(studentsTitle);
            studentsPanel.Controls.Add(dgvStarStudents);

            mainContent.Controls.Add(chartPanel);
            mainContent.Controls.Add(studentsPanel);

            this.Controls.Add(mainContent);
        }

        private void InitializeDashboard()
        {
            db = new Database();
        }

        private void LoadStats()
        {
            try
            {
                // Load real statistics from database
                int studentCount = db.GetStudentCount();
                int teacherCount = db.GetTeacherCount();

                // Update labels if they exist
                foreach (Control control in this.Controls)
                {
                    if (control is Panel panel)
                    {
                        foreach (Control panelControl in panel.Controls)
                        {
                            if (panelControl is Panel card)
                            {
                                foreach (Control cardControl in card.Controls)
                                {
                                    if (cardControl is Label label && label.Text == "15.00K")
                                    {
                                        label.Text = studentCount.ToString("N0");
                                    }
                                    else if (cardControl is Label label2 && label2.Text == "2.00K")
                                    {
                                        label2.Text = teacherCount.ToString("N0");
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading statistics: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private Image GetDefaultAvatar()
        {
            // Create a default avatar
            Bitmap bmp = new Bitmap(40, 40);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.FromArgb(74, 111, 165));
                g.DrawString("A", new Font("Arial", 16), Brushes.White, new PointF(12, 8));
            }
            return bmp;
        }

        private void MenuButton_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null)
            {
                string formName = btn.Tag.ToString();

                switch (formName)
                {
                    case "Dashboard":
                        // Already on dashboard
                        break;
                    case "Students":
                        StudentsForm studentsForm = new StudentsForm();
                        studentsForm.Show();
                        this.Hide();
                        break;
                    case "Teachers":
                        TeachersForm teachersForm = new TeachersForm();
                        teachersForm.Show();
                        this.Hide();
                        break;
                    case "Attendance":
                        AttendanceForm attendanceForm = new AttendanceForm();
                        attendanceForm.Show();
                        this.Hide();
                        break;
                    case "Results":
                        ResultsForm resultsForm = new ResultsForm();
                        resultsForm.Show();
                        this.Hide();
                        break;
                    case "Logout":
                        Application.Exit();
                        break;
                }
            }
        }
    }
}